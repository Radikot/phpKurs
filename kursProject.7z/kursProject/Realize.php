<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 24.12.2017
 * Time: 18:11
 */
require("tfpdf.php");
$pdf = new tFPDF('P', 'mm', 'A4');
$pdf->AddPage();
$textColour = array(0, 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->AddFont('DejaVu', '', 'DejaVuSansCondensed.ttf', true);
$pdf->SetFont('DejaVu', '', 16);
$pdf->SetTitle("Реализация заказа №$_GET[ID]",true);

$pdf->Write(20,"Реализация заказа №$_GET[ID]");
$pdf->SetFont('DejaVu', '', 12);
$pdf->SetY(40,true);
$w=32.3;
$h=12;
$i=0;
$pdf->Cell($w, $h, "Артикул", 1, 0, "C");
$w2=$w*2;
$pdf->Cell(2*$w, $h, "Товар", 1, 0, "C");
$pdf->Cell($w, $h, "Количество", 1, 0, "C");
$pdf->Cell($w, $h, "Цена", 1, 0, "C");
$pdf->Cell($w, $h, "Сумма", 1, 1, "C");

$sumAll=0;
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID])) {
    $query = "SELECT * FROM Order_Product Where Order_ID='$_GET[ID]'";
    $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    while ($orderParams = mysqli_fetch_assoc($result))//данные заказа
    {
        $query1 = "Select Articul, Name, Cost from Product where ID=$orderParams[Product_ID]";
        $result1 = mysqli_query($connection, $query1) or die("Ошибка " . mysqli_error($connection));
        $resRow = mysqli_fetch_assoc($result1);
        $pdf->Cell($w, $h, $resRow[Articul], 1, 0, "C");
        $pdf->Cell(2*$w, $h, $resRow[Name], 1, 0, "C");
        $pdf->Cell($w, $h, $orderParams[Number], 1, 0, "C");
        $pdf->Cell($w, $h, $resRow[Cost], 1, 0, "C");
        $sum=(int)$orderParams[Number]*(int)$resRow[Cost];
        $sumAll+=$sum;
        $sum=number_format($sum,2);

        $pdf->Cell($w, $h, $sum, 1, 1, "C");
    }
    $sumAll=number_format($sumAll,2);
    $x=$pdf->GetX();
    $y=$pdf->GetY();
    $x+=4*$w;
    $pdf->SetX($x);
    $pdf->Write($h,"Итого:");
    $x+=$w;
    $pdf->SetX($x);
    $pdf->Cell($w, $h, $sumAll, 1, 0, "C");
    $pdf->Output("Realize.pdf", "I");
}
?>