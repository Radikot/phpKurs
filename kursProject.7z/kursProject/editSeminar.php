<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']==1) {
    header("Location: /kursProject/main.php");
    exit;
}
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));

$query="SELECT * FROM seminar Where ID=$_GET[ID_Seminar]";
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$seminarParams=mysqli_fetch_assoc($result);
$query="SELECT Name,ID FROM Brand";
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Семинар</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
            text-align: center;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-4 col-md-offset-4 ">
<form action="editSeminars.php" method="post">
    <div class="form-group">
    <label for="Brand">Бренд семинара</label>
    <select name="Brand" id="Brand" required class="form-control">
        <?
        while($brands=mysqli_fetch_assoc($result)) {
            if($brands[ID]==$seminarParams[Brand_ID])
                $selected="selected";
            else
                $selected="";
            echo "<option value='$brands[ID]' class='form-control' $selected>$brands[Name]</option>";
        }
        ?>
    </select>
    </div>
    <div class="form-group">
    <label for="Topic">Тема семинара</label>
    <?
    echo "<input type='text' name='Topic' id='Topic' value='$seminarParams[Topic]' class='form-control'>";
    ?>
    </div>
    <div class="form-group">
    <label for="Leader">Ведущий семинара</label>
    <select name="Leader" id="Leader" required class='form-control'>
        <?
        $query='SELECT ID,Name,Surname FROM Leader';
        $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($link));
        while ($leader=mysqli_fetch_assoc($result))
        {
            if($leader[ID]==$seminarParams[Leader_ID])
                $selected="selected";
            else
                $selected="";
            echo "<option value='$leader[ID]' $selected class='form-control'>$leader[Name] $leader[Surname]</option>";
        }?>
    </select>
    </div>
    <div class="form-group">
    <label for="StartTime">Начало семинара</label>
    <?php
    $now=date_create();
    $nowStr=$now->format('Y-m-d\TH:i');
    $startTimeFormat=$seminarParams[StartTime];
    $startTimeFormat=str_replace(" ","T",$startTimeFormat);
    $startTimeFormat=substr($startTimeFormat,0,-3);
    echo "<input type='datetime-local' min=$nowStr id='StartTime' name='StartTime' value=$startTimeFormat required class='form-control'></div>";
    echo "<div class='form-group'> <label for='Duration'>Продолжительность семинара</label>";
    echo "<input type='time' id='Duration' name='Duration' value=$seminarParams[Duration] required class='form-control'></div>";
    echo "<input type='hidden' name='ID' value=$seminarParams[ID]>";?>
        <button class="btn btn-primary">Отправить</button>
</form>
</body>
</html>