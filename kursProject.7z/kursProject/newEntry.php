<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Новая запись</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-offset-4 col-md-4">
<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 17.12.2017
 * Time: 16:15
 */
if(isset($_GET[ID_Seminar])) {?>
    <form action="viewSeminar.php" method="post" >
        <? echo "<input type='hidden' name='ID_Seminar' value=$_GET[ID_Seminar] required>";?>
        <div class="form-group">
        <label for="Name">Ваше имя: </label><input type="text" id="Name" name="Name" class="form-control">
        </div>
        <div class="form-group">
        <label for="PhoneNumber">Ваш номер телефона: </label>
        <input type="tel" name="PhoneNumber" id="PhoneNumber" pattern="(8|\+7)\s?[\(]{0,1}9[0-9]{2}[\)]{0,1}\s?\d{3}[-]{0,1}\d{2}[-]{0,1}\d{2}" required class="form-control">
        </div>
        <button class="btn btn-primary">Отправить</button>
    </form>
    <?} else {
    echo'На страницу не были переданы необходимые параметры.';
}?>
        </div>
    </div>
</div>
</body>
</html>
