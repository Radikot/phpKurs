<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 18.12.2017
 * Time: 22:10
 */
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
$query = "SELECT role_ID, login FROM login_pass WHERE login = '$_POST[Login]' AND pass = '".MD5($_POST[Pass])."'";
$result = mysqli_query($connection, $query) or die('Запрос не удался: ' . mysqli_error($connection));
$resRow = mysqli_fetch_assoc($result);
if ($resRow <> null) {
    session_start();
    $_SESSION['auth'] = 1;
    $_SESSION['ID'] = $_POST[Login];
    $_SESSION['level'] = $resRow['role_ID'];
    switch($_SESSION['level'])
    {
        case 1:
            header("Location: /kursProject/Buyer.php");
            break;
        case 2:
            header("Location: /kursProject/SalesRepresentative.php");
            break;
        case 3:
            header("Location: /kursProject/admin.php");
    }
} else {
    header("Location: /kursProject/main.php?err=1");
}
?>