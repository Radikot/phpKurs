<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Бренд</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-4 col-md-offset-4">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))
{
    $query="SELECT * FROM Entry Where ID='$_GET[ID]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $entryParams=mysqli_fetch_assoc($result);
    echo "
<form action='editEntries.php?new=0' method='post'>
<div class='form-group'>
    <input type='hidden' name='ID' value='$_GET[ID]'>    
    <label for='Name'>Имя</label>
    <input type='text' id='Name' name='Name' value='$entryParams[Name]' class='form-control'>
    </div>
    <div class='form-group'>
    <label for='PhoneNumber'>Телефон</label>
    <input type='text' name='PhoneNumber' id='PhoneNumber' value='$entryParams[PhoneNumber]' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Seminar'>Семинар</label>
    <select name='Seminar' id='Seminar' required class='form-control'>";
    $query='SELECT * FROM seminar';
    $result=mysqli_query($connection,$query) or die('Ошибка ' . mysqli_error($link));
    while ($seminar=mysqli_fetch_assoc($result))
    {
        if($seminar[ID]==$entryParams[ID_Seminar])
            $selected='selected';
        else
            $selected='';
        echo "<option value=$seminar[ID] $selected class='form-control'>$seminar[StartTime]</option>";
    }echo"
    </select>
    </div>
    <button class='btn btn-primary'>Отправить</button>
    </form>";
}
else
{echo "
<form action='editEntries.php?new=1' method='post'>
<div class='form-group'>
    <label for='Name'>Имя</label>
    <input type='text' id='Name' name='Name' class='form-control'>
    </div>
    <div class='form-group'>
    <label for='PhoneNumber'>Телефон</label>
    <input type='text' name='PhoneNumber' id='PhoneNumber' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Seminar'>Семинар</label>
    <select name='Seminar' id='Seminar' required class='form-control'>";
    $query='SELECT * FROM seminar';
    $result=mysqli_query($connection,$query) or die('Ошибка ' . mysqli_error($link));
    while ($seminar=mysqli_fetch_assoc($result))
    {
        echo "<option value=$seminar[ID] class='form-control'>$seminar[StartTime]</option>";
    }echo"
    </select>
    </div>
    <button class='btn btn-primary'>Отправить</button>
    </form>";}?>
    </div>
</div>
</body>
</html>