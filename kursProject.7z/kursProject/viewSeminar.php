<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Покупатель</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
        th
        {
            text-align: center;
        }
        tr
        {
            text-align: center;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-10 col-md-offset-1">
<!-------------------------------------->
<?
if (isset($_GET['y'])) $y=$_GET['y'];
if (isset($_GET['m'])) $m=$_GET['m'];
if (isset($_GET['d'])) $d=$_GET['d'];
//


list($y,$m,$d)=explode("-",$_GET['date']);
$now="$y-$m-".sprintf("%02d",$d);
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));

if (isset($_POST[ID_Seminar])AND isset($_POST[Name]) AND isset($_POST[PhoneNumber]))
{
    $query = "INSERT INTO Entry (ID_Seminar, Name, PhoneNumber) VALUES ('$_POST[ID_Seminar]','$_POST[Name]','$_POST[PhoneNumber]')";
    $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
}
$query='SELECT * FROM seminar';
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$resultForParam=$result;
include 'Calendar.php';
$resArr=array();
while($resultRow=mysqli_fetch_assoc($result))
    array_push($resArr,$resultRow[StartTime]);
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
my_calendar($resArr);
echo '<table class="table"><caption>Семинары в выбранный день</caption>
<tr><th>Бренд семинара</th>
<th>Тема семинара</th>
<th>Имя ведущего семинара</th>
<th>Начало семинара</th>
<th>Продолжительность семинара</th>
<th>Запись</th></tr>';
while($seminarParams=mysqli_fetch_assoc($result))//данные искомого семинара
{
    echo '<tr>';
    $seminarDate=substr($seminarParams[StartTime],0,10);
    if($seminarDate==$now) {
        echo '<td>';
        $query = 'SELECT Name FROM Brand WHERE ID=' . $seminarParams[Brand_ID];
        $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        $resultRow = mysqli_fetch_assoc($result1);
        echo $resultRow[Name];
        echo '</td><td>';
        if ($seminarParams[Topic]) {
            echo $seminarParams[Topic];
        } else echo '-';
        echo '</td><td>';
        $query = 'SELECT Name,Surname FROM Leader WHERE ID=' . $seminarParams[Leader_ID];
        $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($link));
        $resultRow = mysqli_fetch_assoc($result1);
        echo $resultRow[Name] . " " . $resultRow[Surname];
        echo '</td><td>';
        echo $seminarParams[StartTime];
        echo '</td><td>';
        echo $seminarParams[Duration] . "\n\n";
        echo '</td><td>';
        echo "<a href='http://localhost/kursProject/newEntry.php?ID_Seminar=$seminarParams[ID]'>Записаться</a></td>";
    }
}?>
</body>
</html>
