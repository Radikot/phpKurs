<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 17.12.2017
 * Time: 12:35
 */
if($_GET[err]==1)
    $formErr= "Неправильно введён логин-пароль";
if(isset($_POST['Name'])AND isset($_POST['Surname'])AND isset($_POST['Patronymic'])AND isset($_POST['Brand'])AND isset($_POST['email'])AND isset($_POST['PhoneNumber']))
{
    $connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
    $query="SELECT Value FROM constants WHERE Name='emailForBuyers'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $resRow=mysqli_fetch_assoc($result);
    $email=$resRow[Value];
    $query="SELECT Name FROM Brand WHERE ID=$_POST[Brand]";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $resRow=mysqli_fetch_assoc($result);
    $brand=$resRow[Name];
    $message="Имя покупателя: $_POST[Name] Фамилия: $_POST[Surname] Отчество: $_POST[Patronymic] Предпочитаемый бренд: $brand Почта: $_POST[email]";
    $res=mail($email,'Новый покупатель',$message);
    $query = "INSERT INTO Buyer (Name, Surname,Patronymic,Brand,email,PhoneNumber) VALUES ('$_POST[Name]','$_POST[Surname]','$_POST[Patronymic]','$_POST[Brand]','$_POST[email]','$_POST[PhoneNumber]')";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <form class="navbar-form navbar-right" method="post" action="login.php">
                <div class="form-group">
                    <small id="emailHelp" class="form-text text-muted"><?php echo "$formErr";?></small>
                    <input type="text" name="Login" class="form-control" placeholder="Login">
                    <input type="password" name="Pass" class="form-control" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-default">Войти</button>
            </form>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-9 " id="sidebar" role="navigation">
        </div>
        <div class="col-xs-6 col-sm-3 " id="sidebar" role="navigation">
            <div class="list-group">
                <a href="viewSeminar.php" class="list-group-item">Расписание семинаров</a>
                <a href="newBuyer.php" class="list-group-item">Стать оптовым покупателем</a>
                <a href="ScheduleMonth.php" class="list-group-item">Печатная форма расписания</a>
                <a href="changePass.php" class="list-group-item">Сменить пароль</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
