<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']==1) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 15.12.2017
 * Time: 12:15
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Администратор</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>-->
        <style type="text/css">
            body
            {
                padding-top: 90px;
                text-align: center;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }
            th
            {
                text-align: center;
            }
        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1" >
                <?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID_Seminar]))//Отменить семинар
{
    $query="DELETE from seminar WHERE ID='$_GET[ID_Seminar]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Семинар успешно отменён</small>";
}
if(isset($_POST[Brand])AND isset($_POST[Leader])AND isset($_POST[StartTime])AND isset($_POST[Duration]))//изменение семинара
{
    $StartTime=new DateTime($_POST[StartTime]);
    list($h,$m)=explode(":",$_POST[Duration]);
    $DurationInterval=new DateInterval("PT".(int)$h."H".(int)$m."M");
    $FinalTime=date_add($StartTime,$DurationInterval);
    $FinalTimeStr=date_format($FinalTime, 'Y-m-d H:i:s');

    $query="SELECT StartTime, FinalTime FROM seminar";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $f=true;
    while($resRow=mysqli_fetch_assoc($result)AND $f)//Проверка на совпадение времени проведения семинаров
    {
        $StartTime1=date_create($resRow[StartTime]);
        $FinalTime1=date_create($resRow[FinalTime]);
        if(!(($StartTime>$FinalTime1 AND $FinalTime>$FinalTime1)OR($StartTime<$StartTime1 AND $FinalTime<$StartTime1)))
            $f=false;//f-значит совпало
    }
    if($f)
    {
        $query="UPDATE seminar SET Brand_ID='$_POST[Brand]', Topic='$_POST[Topic]', Leader_ID='$_POST[Leader]',StartTime='$_POST[StartTime]',Duration='$_POST[Duration]',FinalTime='$FinalTimeStr' WHERE ID='$_POST[ID]'";
        $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Семинар успешно изменён</small>";

    } else
        echo "<small class='form-text text-muted'>В выбранное время нельзя провести семинар</small>";
}
include 'Calendar.php';

$query='SELECT StartTime FROM Seminar';//where
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$resArr=array();
while($resRow=mysqli_fetch_assoc($result))//Заполняем массив датами семинаров
{
    array_push($resArr,$resRow['StartTime']);
}
my_calendar($resArr);
if(isset($_GET['date']))
{
    $curDate=date_create($_GET['date']);
    $query="SELECT * FROM Seminar WHERE StartTime LIKE '$_GET[date]%'";
    $result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
}
echo '<table class="table"><caption>Семинары в выбранный день</caption>
    <tr><th>Бренд семинара</th>
        <th>Тема семинара</th>
        <th>Имя ведущего семинара</th>
        <th>Начало семинара</th>
        <th>Продолжительность семинара</th>
        </tr>';
while($seminarParams=mysqli_fetch_assoc($result))//данные семинара
{
    echo '<tr>';
    $seminarDate=substr($seminarParams[StartTime],0,10);
    echo '<td>';
    $query = 'SELECT Name FROM Brand WHERE ID=' . $seminarParams[Brand_ID];
    $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    $resultRow = mysqli_fetch_assoc($result1);
    echo $resultRow[Name];
    echo '</td><td>';
    if ($seminarParams[Topic])
    {echo $seminarParams[Topic];
    } else echo '-';
    echo '</td><td>';
    $query = 'SELECT Name,Surname FROM Leader WHERE ID=' . $seminarParams[Leader_ID];
    $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($link));
    $resultRow = mysqli_fetch_assoc($result1);
    echo $resultRow[Name] . " " . $resultRow[Surname];
    echo '</td><td>';
    echo $seminarParams[StartTime];
    echo '</td><td>';
    echo $seminarParams[Duration]."\n\n";
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editSeminar.php?ID_Seminar=$seminarParams[ID]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editSeminars.php?ID_Seminar=$seminarParams[ID]'>Отменить</a></td></tr>";

}
echo "</table>";
if($_SESSION['level']==3)
    echo "<a href='http://localhost/kursProject/newSeminar.php'>Новый семинар</a>";
?>
            </div>
        </div>

    </div>
        </div>
    </div>
    </body></html>