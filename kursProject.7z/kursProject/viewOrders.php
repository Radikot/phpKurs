<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Заказы</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-10 col-md-offset-1">
        <?php
        $connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));

        $query="SELECT * FROM Order1";
        $result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo '<table class="table"><caption>Таблица заказов</caption>
    <tr>
    <th>Покупатель</th>
    <th>Сумма</th>
    <th>Дата</th>
    </tr>';
        while($orderParams=mysqli_fetch_assoc($result))//данные заказа
        {
            echo '<tr>';
            echo '<td>';
            $query="SELECT Name, Surname from Buyer WHERE ID=$orderParams[ID_Buyer]";
            $result1=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
            $resRow=mysqli_fetch_assoc($result1);
            echo $resRow[Name].' '.$resRow[Surname];
            echo '</td><td>';
            echo $orderParams[Summ];
            echo '</td><td>';
            echo $orderParams[Date];
            echo '</td><td>';
            echo "<a href='http://localhost/kursProject/viewOrder.php?ID=$orderParams[ID]'>Подробности</a></td>";
            echo "<td><a href='http://localhost/kursProject/Realize.php?ID=$orderParams[ID]'>Печатная форма</a></td>";
        }
        echo '</table>';
        ?>
    </div>
</div>
</body></html>';