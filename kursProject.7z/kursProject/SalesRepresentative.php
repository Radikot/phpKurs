<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 18.12.2017
 * Time: 22:21
 */
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=2) {
    header("Location: /main.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Торговый представитель</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-8 ">
        </div>
        <div class="col-md-2 col-md-offset-2">
            <div class="list-group">
                <a href="editSeminars.php" class="list-group-item">Редактировать семинар</a>
                <a href="newSeminar.php" class="list-group-item">Новый семинар</a>
            </div>
        </div>
    </div>
</div>