<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 24.12.2017
 * Time: 18:11
 */
list($y,$m)=explode("-",$_GET['month']);
$timeArr=array();
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
$query='SELECT StartTime, FinalTime FROM seminar ORDER BY StartTime';
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
while($resRow=mysqli_fetch_assoc($result))
{
    $startStr=$resRow[StartTime];
    $startDT=new DateTime($startStr);
    if($startDT->format("Y")==$y AND $startDT->format("m")==$m) {
        $startStrHi = $startDT->format("H:i");
        $startStrD = $startDT->format("d");
        $finalStr = $resRow[FinalTime];
        $finalDT = new DateTime($finalStr);
        $finalStrHi = $finalDT->format("H:i");
        $timeStr = $startStrHi . " - " . $finalStrHi;
        if (!isset($timeArr[(int)$startStrD]))
            $timeArr[(int)$startStrD] = array();
        array_push($timeArr[(int)$startStrD], $timeStr);
    }
}

require("tfpdf.php");
$pdf=new tFPDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetTitle("Расписание",true);
$textColour=array(0,0,0);
$pdf->SetTextColor(0,0,0);
$pdf->AddFont('DejaVu','','DejaVuSansCondensed.ttf',true);
$pdf->SetFont('DejaVu','',11);


if (isset($_GET['y'])) $y=(int)$_GET['y'];
if (isset($_GET['m'])) $m=(int)$_GET['m'];
if (!isset($y) OR $y < 1970 OR $y > 2037) $y=date("Y");
if (!isset($m) OR $m < 1 OR $m > 12) $m=date("m");
$month_stamp=mktime(0,0,0,$m,1,$y);
$day_count=date("t",$month_stamp);
$weekday=date("w",$month_stamp);
if ($weekday==0) $weekday=7;
$start=-($weekday-2);
$last=($day_count+$weekday-1) % 7;
if ($last==0) $end=$day_count; else $end=$day_count+7-$last;
$today=date("Y-m-d");
$prev=date('?\m=m&\y=Y',mktime (0,0,0,$m-1,1,$y));
$next=date('?\m=m&\y=Y',mktime (0,0,0,$m+1,1,$y));

switch($m)
{
    case 1:
        $mStr="Январь";
        break;
    case 2:
        $mStr="Февраль";
        break;
    case 3:
        $mStr="Март";
        break;
    case 4:
        $mStr="Апрель";
        break;
    case 5:
        $mStr="Май";
        break;
    case 6:
        $mStr="Июнь";
        break;
    case 7:
        $mStr="Июль";
        break;
    case 8:
        $mStr="Август";
        break;
    case 9:
        $mStr="Сентябрь";
        break;
    case 10:
        $mStr="Октябрь";
        break;
    case 11:
        $mStr="Ноябрь";
        break;
    case 12:
        $mStr="Декабрь";
        break;
}
$pdf->Cell(0,10,"Расписание на $mStr $y",0,2,'C');
$weekArr=array("Пн","Вт","Ср","Чт","Пт","Сб");
foreach ($weekArr as $item)
    $pdf->Cell(40,10,$item,1,0,'C');
$pdf->Cell(40,10,"Вс",1,1,'C');
$i=0;
$ln=1;
for($d=$start;$d<=$end;$d++) {
    if (($i+1) % 7 == 0 AND $i!=0) $ln = 1; else $ln = 0;
    if ($d < 1 OR $d > $day_count) {
        $pdf->Cell(40, 20, " ", 1, $ln, 'L');
    } else {
        if(isset($timeArr[$d]))
        {
            $x=$pdf->GetX();
            $y=$pdf->GetY();
            $SeminarsTimeStr='';
            $j=0;
            $count=count($timeArr[$d]);
            $pdf->Cell(40, 20/($count+1), "$d", "RLT", 2, 'C');
            foreach($timeArr[$d] as $value)
            {
                if($j==$count-1)
                    $pdf->Cell(40, 20/($count+1), "$value", "RLB", 2, 'C');
                else
                    $pdf->Cell(40, 20/($count+1), "$value", "RL", 2, 'C');
                $j++;
            }
            $x+=40;
            $pdf->SetY($y);
            $pdf->SetX($x);
        }
        else
        $pdf->Cell(40, 20, "$d", 1, $ln, 'C');
    }
    $i++;
}
$pdf->Output("Schedule.pdf","I");
?>