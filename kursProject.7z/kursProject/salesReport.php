<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 24.12.2017
 * Time: 18:11
 */

require("tfpdf.php");
list($y,$m)=explode("-",$_GET['month']);
switch($m)
{
    case 1:
        $mStr="Январь";
        break;
    case 2:
        $mStr="Февраль";
        break;
    case 3:
        $mStr="Март";
        break;
    case 4:
        $mStr="Апрель";
        break;
    case 5:
        $mStr="Май";
        break;
    case 6:
        $mStr="Июнь";
        break;
    case 7:
        $mStr="Июль";
        break;
    case 8:
        $mStr="Август";
        break;
    case 9:
        $mStr="Сентябрь";
        break;
    case 10:
        $mStr="Октябрь";
        break;
    case 11:
        $mStr="Ноябрь";
        break;
    case 12:
        $mStr="Декабрь";
        break;
}
$pdf = new tFPDF('P', 'mm', 'A4');
$pdf->AddPage();
$textColour = array(0, 0, 0);
$pdf->SetTextColor(0, 0, 0);
$pdf->AddFont('DejaVu', '', 'DejaVuSansCondensed.ttf', true);
$pdf->SetFont('DejaVu', '', 16);
$pdf->SetTitle("Отчёт по продажам",true);


$pdf->Write(20,"Отчёт по продажам за $mStr $y");
$pdf->SetFont('DejaVu', '', 12);
$pdf->SetY(40,true);
$w=38;
$h=12;
$pdf->Cell($w, $h, "Покупатель", 1, 0, "C");
$pdf->Cell(2*$w, $h, "Наименование", 1, 0, "C");
$pdf->Cell($w, $h, "Количество", 1, 0, "C");
$pdf->Cell($w, $h, "Стоимость", 1, 1, "C");

$sumAll=0;
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));

    $query = "SELECT * FROM Order1 Where Date LIKE '$_GET[month]%'";
    $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    while ($orderParams = mysqli_fetch_assoc($result))//данные заказа
    {
        $query4="Select Name, Surname from Buyer Where ID=$orderParams[ID_Buyer]";
        $result4 = mysqli_query($connection, $query4) or die("Ошибка " . mysqli_error($connection));
        $BuyerParams=mysqli_fetch_assoc($result4);
        $query1 = "Select * from Order_Product where Order_ID=$orderParams[ID]";
        $result1 = mysqli_query($connection, $query1) or die("Ошибка " . mysqli_error($connection));
        while($Order_ProductParams = mysqli_fetch_assoc($result1))
        {
            $query2 = "Select * from Product where ID=$Order_ProductParams[Product_ID]";
            $result2 = mysqli_query($connection, $query2) or die("Ошибка " . mysqli_error($connection));
            $productParams=mysqli_fetch_assoc($result2);
            $pdf->Cell($w, $h, $BuyerParams[Name]." ".$BuyerParams[Surname], 1, 0, "C");
            $pdf->Cell(2*$w, $h, $productParams[Name], 1, 0, "C");
            $pdf->Cell($w,$h,$Order_ProductParams[Number],1,0,"C");
            $sum=((int)$Order_ProductParams[Number]*$productParams[Cost]);
            $sumAll+=$sum;
            $sum=number_format($sum,2);
            $pdf->Cell($w,$h,$sum,1,1,"C");
        }
    }
    $sumAll=number_format($sumAll,2);
    $x=$pdf->GetX();
    $y=$pdf->GetY();
    $x+=3*$w;
    $pdf->SetX($x);
    $pdf->Write($h,"Итого:");
    $x+=$w;
    $pdf->SetX($x);
    $pdf->Cell($w, $h, $sumAll, 1, 0, "C");
    $pdf->Output("Realize.pdf", "I");

$pdf->Output("salesReport.pdf", "I");
?>