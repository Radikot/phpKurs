<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Заказы</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            text-align: center;
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
        th
        {
            text-align: center;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-10 col-md-offset-1">
<table class="table"><caption>Заказ <?echo $_GET[ID]?></caption>
    <tr>
        <th>Артикул</th>
        <th>Наименование</th>
        <th>Количество</th>
    </tr>
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))
{
    $query="SELECT * FROM Order_Product Where Order_ID='$_GET[ID]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
while($orderParams=mysqli_fetch_assoc($result))//данные заказа
{
    $query1="Select Articul, Name from Product where ID=$orderParams[Product_ID]";
    $result1=mysqli_query($connection,$query1) or die("Ошибка " . mysqli_error($connection));
    $resRow=mysqli_fetch_assoc($result1);
    echo '<tr>';
    echo '<td>';
    echo $resRow[Articul];
    echo '</td><td>';
    echo $resRow[Name];
    echo '</td><td>';
    echo $orderParams[Number];
    echo '</td></tr>';
}}?>
</table>
    </div>
</div>
</body>
</html>