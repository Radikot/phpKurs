<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<?
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 19.01.2018
 * Time: 14:35
 */
if(isset($_POST['email']))
{
    $connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
    $query="Select login from Buyer where email='$_POST[email]'";
    $result=mysqli_query($connection, $query) or die("error " . mysqli_error($connection));
    $resRow=mysqli_fetch_assoc($result);
    if(!isset($resRow[login]))
        echo "There is no such email";
    else {
        function generatePassword($length = 8)
        {
            $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
            $numChars = strlen($chars);
            $string = '';
            for ($i = 0; $i < $length; $i++) {
                $string .= substr($chars, rand(1, $numChars) - 1, 1);
            }
            return $string;
        }
        $p = generatePassword();
        mail($_POST[email], "Смена пароля", "Новый пароль для авторизации в системе ProfiLine: " . $p);
        $query = "UPDATE login_pass SET pass='".MD5($p)."' WHERE login='$resRow[login]'";
        $result=mysqli_query($connection, $query) or die("error " . mysqli_error($connection));
        echo "Пароль успешно изменён";
    }
}?>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
        <form>
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type='email' id='email' name='email' class="form-control">
                <small id="emailHelp" class="form-text text-muted">Введите адрес почты, введённый вами при регистрации.</small>
            </div>
            <button type="submit" class="btn btn-primary">Отправить</button>
        </form>
        </div>
    </div>
</div>
</body>

