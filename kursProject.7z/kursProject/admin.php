<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 18.12.2017
 * Time: 22:20
 */
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Администратор</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>-->
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-8" >
        </div>
        <div class="col-md-2 col-md-offset-2">
            <div class="list-group">
                <a href='editLogins.php' class="list-group-item">Учётные записи</a>
                <a href='editSeminars.php' class="list-group-item">Семинары</a>
                <a href='editBrands.php' class="list-group-item">Бренды</a>
                <a href='editBuyers.php' class="list-group-item">Покупатели</a>
                <a href='editConstants.php' class="list-group-item">Постоянные</a>
                <a href='editEntries.php' class="list-group-item">Записи</a>
                <a href='editLeaders.php' class="list-group-item">Ведущие</a>
                <a href='editProducts.php' class="list-group-item">Продукты</a>
                <a href='viewOrders.php' class="list-group-item">Заказы</a>
                <a href='salesReportMonth.php' class="list-group-item">Отчёт о продажах</a>
            </div>
        </div>
    </div>
</div>
</body></html>