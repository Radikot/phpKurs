<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Покупатель</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <style type="text/css">
            body
            {
                padding-top: 90px;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }

        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row col-md-10 col-md-offset-1">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[Login]))//Удалить запись
{
    $query="DELETE from login_pass WHERE login='$_GET[Login]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Учётная запись успешно удалена</small>";
}
if(isset($_POST[Login])AND isset($_POST[Role]))//Изменение записи
{
    if($_GET['new']=='0') {
        if ($_POST[Password] != '')
            $query = "UPDATE login_pass SET pass=MD5($_POST[Password]), Name='$_POST[Name]', role_ID=$_POST[Role] WHERE login='$_POST[Login]'";
        else
            $query = "UPDATE login_pass SET Name='$_POST[Name]', role_ID=$_POST[Role] WHERE login='$_POST[Login]'";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Учётная запись успешно изменена</small>";
    } }if($_GET['new']=='1') {
        $query = "INSERT into login_pass (login, pass, Name, role_ID) VALUES ('$_POST[Login]',MD5('$_POST[Password]'),'$_POST[Name]','$_POST[Role]')";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Учётная запись успешно добавлена</small>";
    }
$query="SELECT * FROM login_pass";
$result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
echo '<table class="table"><caption>Таблица учётных записей</caption>
    <tr>
    <th>Логин</th>
    <th>Имя</th>
    <th>Роль</th>
    </tr>';
while($logParams=mysqli_fetch_assoc($result))//данные семинара
{
    echo '<tr>';
    echo '<td>';
    echo $logParams[login];
    echo '</td><td>';
    if ($logParams[Name])
    echo $logParams[Name];
     else echo '-';
    echo '</td><td>';
    $query = 'SELECT RoleName FROM Roles WHERE ID=' . $logParams[role_ID];
    $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($link));
    $resultRow = mysqli_fetch_assoc($result1);
    echo $resultRow[RoleName];
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editLogin.php?Login=$logParams[login]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editLogins.php?Login=$logParams[login]'>Удалить</a></td></tr>";
}
echo"</table>";
?>
            <a href='http://localhost/kursProject/editLogin.php'>Новая учётная запись</a>
        </div>
    </body>
</html>