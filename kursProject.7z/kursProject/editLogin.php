<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Покупатель</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-4 col-md-offset-4 ">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[Login]))
{
$query="SELECT * FROM login_pass Where login='$_GET[Login]'";
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$logParams=mysqli_fetch_assoc($result);
echo "
<form action='editLogins.php?new=0' method='post'>
<div class='form-group'>
    <label for='Login'>Логин</label>
    <input type='text' id='Login' class='form-control' value='$_GET[Login]' disabled>
</div>
    <input type='hidden' name='Login' value='$_GET[Login]'>
<div class='form-group'>
    <label for='Name'>Имя</label>
    <input type='text' name='Name' id='Name' value='$logParams[Name]' class='form-control'>
</div>
<div class='form-group'>
    <label for='Role'>Роль</label>
    <select name='Role' id='Role' class='form-control'>";
        $query='SELECT ID,RoleName FROM Roles';
        $result=mysqli_query($connection,$query) or die('Ошибка ' . mysqli_error($link));
        while ($role=mysqli_fetch_assoc($result))
        {
            if($role[ID]==$logParams[role_ID])
                $selected='selected';
            else
                $selected='';
            echo "<option value=$role[ID] $selected class='form-control'>$role[RoleName]</option>";
        }?>
    </select>
    </div>
    <div class='form-group'>
    <label for='Password'>Новый пароль</label>
    <input type='password' name='Password' id='Password' class='form-control'>
    </div>
    <button class="btn-primary btn">Отправить</button>
</form>
    <?}
    else
        {echo "
<form action='editLogins.php?new=1' method='post'>
<div class='form-group'>
    <label for='Login'>Логин</label>
    <input type='text' id='Login' name='Login' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Name'>Имя</label>
    <input type='text' name='Name' id='Name' class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Role'>Роль</label>
    <select name='Role' id='Role' required class='form-control'>";
$query='SELECT ID,RoleName FROM Roles';
$result=mysqli_query($connection,$query) or die('Ошибка ' . mysqli_error($link));
while ($role=mysqli_fetch_assoc($result))
{
    echo "<option value=$role[ID]>$role[RoleName]</option>";
}?>
</select>
</div>
    <div class='form-group'>
<label for='Password'>Новый пароль</label>
<input type='password' name='Password' id='Password' required class='form-control'>
    </div>
<button class="btn-primary btn">Отправить</button>
</form><?}?>
    </body>
</html>