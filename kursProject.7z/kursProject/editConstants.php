<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Покупатели</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <style type="text/css">
            body
            {
                padding-top: 90px;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }

        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row col-md-10 col-md-offset-1">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))//Удалить постоянную
{
    $query="DELETE from constants WHERE ID=$_GET[ID]";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Постоянная успешно удалена</small>";
}
if(isset($_POST[ID]))//Изменение записи

    if($_GET['new']=='0'){
        $query = "UPDATE constants SET Name='$_POST[Name]', Value='$_POST[Value]' WHERE ID=$_POST[ID]";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Постоянная успешно изменена</small>";
    }
    if($_GET['new']=='1'){
        $query = "INSERT into constants (Name, Value) VALUES ('$_POST[Name]','$_POST[Value]')";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Постоянная успешно добавлена</small>";
    }

$query="SELECT * FROM constants";
$result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
?><table class="table"><caption>Таблица постоянных</caption>
    <tr>
    <th>Название</th>
    <th>Значение</th>
    </tr>
<?while($consParams=mysqli_fetch_assoc($result))//данные постоянной
{
    echo '<tr>';
    echo '<td>';
    echo $consParams[Name];
    echo '</td><td>';
    echo $consParams[Value];
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editConstant.php?ID=$consParams[ID]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editConstants.php?ID=$consParams[ID]'>Удалить</a></td></tr>";
}
?></table><a href='http://localhost/kursProject/editConstant.php'>Новая постоянная</a>
        </div></div></table></body></html>