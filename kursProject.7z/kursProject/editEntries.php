<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Покупатели</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <style type="text/css">
            body
            {
                padding-top: 90px;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }

        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row col-md-10 col-md-offset-1">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))//Удалить запись
{
    $query="DELETE from Entry WHERE ID='$_GET[ID]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Запись успешно удалена</small>";
}
if(isset($_POST[ID]))//Изменение записи
{
    if($_GET['new']=='0')
    {
        $query = "UPDATE Entry SET ID_Seminar='$_POST[Seminar]', Name='$_POST[Name]', PhoneNumber='$_POST[PhoneNumber]' WHERE ID=$_POST[ID]";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Запись успешно изменена</small>";
    }
}
if($_GET['new']=='1')
{
    $query = "INSERT into Entry (ID_Seminar, Name, PhoneNumber) VALUES ('$_POST[Seminar]','$_POST[Name]','$_POST[PhoneNumber]')";
    $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Запись успешно добавлена</small>";
}
$query="SELECT * FROM Entry";
$result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));?>
<table class="table"><caption>Таблица записей</caption>
    <tr>
        <th>Имя</th>
        <th>Телефон</th>
        <th>Семинар</th>
    </tr><?
while($entryParams=mysqli_fetch_assoc($result))//данные семинара
{
    echo '<tr>';
    echo '<td>';
    if ($entryParams[Name])
        echo $entryParams[Name];
    else echo '-';
    echo '</td><td>';
    echo $entryParams[PhoneNumber];
    echo '</td><td>';
    $query = 'SELECT StartTime FROM seminar WHERE ID=' . $entryParams[ID_Seminar];
    $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($link));
    $resultRow = mysqli_fetch_assoc($result1);
    echo $resultRow[StartTime];
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editEntry.php?ID=$entryParams[ID]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editEntries.php?ID=$entryParams[ID]'>Удалить</a></td></tr>";
}?>
</table><a href='http://localhost/kursProject/editEntry.php'>Новая запись</a>
        </div>
    </div>

</body></html>';