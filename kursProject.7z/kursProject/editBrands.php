<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Бренды</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <style type="text/css">
            body
            {
                padding-top: 90px;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }

        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row col-md-10 col-md-offset-1">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))//Удалить запись
{
    $query="DELETE from Brand WHERE ID=$_GET[ID]";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Бренд успешно удалён</small>";
}
if(isset($_POST[ID]))//Изменение записи
{
    if($_GET['new']=='0') {
        $query = "UPDATE Brand SET Name='$_POST[Name]' WHERE ID='$_POST[ID]'";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Бренд успешно изменен</small>";
    } }
    if($_GET['new']=='1') {
        $query = "INSERT into Brand (Name) VALUES ('$_POST[Name]')";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Бренд успешно добавлен</small>";
    }

$query="SELECT * FROM Brand";
$result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
echo '<table class="table"><caption>Таблица брендов</caption>
    <tr><th>Название</th></tr>';
while($brandParams=mysqli_fetch_assoc($result))//данные семинара
{
    echo '<tr>';
    echo '<td>';
    echo $brandParams[Name];
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editBrand.php?ID=$brandParams[ID]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editBrands.php?ID=$brandParams[ID]'>Удалить</a></td></tr>";
}
echo "</table><a href='http://localhost/kursProject/editBrand.php'>Новый бренд</a></div></div>";
echo '</body></html>';