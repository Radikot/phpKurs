<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 17.12.2017
 * Time: 21:27
 */
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
$query='SELECT ID,Name FROM Brand';
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$resRow=mysqli_fetch_assoc($result);
$email=$resRow['emailForBuyers'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Новый покупатель</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>-->
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4" >
            <form action="main.php" method="post">
                <div class="form-group">
                <label for="Name">Имя: </label>
                <input type="text" name="Name" id="Name" required class="form-control">
                </div>
                <div class="form-group">
                <label for="Surname">Фамилия: </label>
                <input type="text" name="Surname" id="Surname" required class="form-control">
                </div>
                <div class="form-group">
                <label for="Patronymic">Отчество: </label>
                <input type="text" name="Patronymic" id="Patronymic" required class="form-control">
                </div>
                <div class="form-group">
                    <label for="Brand">Интересующий бренд</label>
                <select name="Brand" id="Brand" required class="form-control">
                    <?
                    while ($rowRes=mysqli_fetch_assoc($result))
                    {
                        echo "<option value='$rowRes[ID]' class=\"form-control\">$rowRes[Name]</option>";
                    }?>
                </select>
                </div>
                <div class="form-group">
                <label for="email">Электронная почта: </label>
                <input type="email" name="email" id="email" class="form-control">
                </div>
                <div class="form-group">
                <label for="PhoneNumber">Номер телефона: </label>
                <input type="tel" id="PhoneNumber" name="PhoneNumber" pattern="(8|\+7)\s?[\(]{0,1}9[0-9]{2}[\)]{0,1}\s?\d{3}[-]{0,1}\d{2}[-]{0,1}\d{2}" required class="form-control">
                </div>
                <button type="button" class="btn btn-primary">Отправить</button>
            </form>
        </div>
    </div>
</div>
</body></html>


