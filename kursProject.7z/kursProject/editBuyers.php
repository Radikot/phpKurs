<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Покупатели</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet">
        <style type="text/css">
            body
            {
                padding-top: 90px;
            }
            .navbar-brand
            {
                height: 70px;
                padding:0px 10px;
            }

        </style>
        <script src="jquery-3.2.1.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    <div class="container">
        <div class="row col-md-10 col-md-offset-1">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))//Удалить запись
{
    $query="DELETE from Buyer WHERE ID='$_GET[ID]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Покупатель успешно удалён</small>";
}
if(isset($_POST[ID]))//Изменение записи
{
    if($_GET['new']=='0') {
        $query = "UPDATE Buyer SET Name='$_POST[Name]', Surname='$_POST[Surname]', PhoneNumber='$_POST[PhoneNumber]', Patronymic='$_POST[Patronymic]', Brand='$_POST[Brand]', email='$_POST[email]', login='$_POST[login]' WHERE ID='$_POST[ID]'";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Покупатель успешно изменён</small>";
    }
}
if($_GET['new']=='1')
{
    $query = "INSERT into Buyer (Name, Surname, PhoneNumber, Patronymic, Brand, email, login) VALUES ('$_POST[Name]','$_POST[Surname]','$_POST[PhoneNumber]','$_POST[Patronymic]','$_POST[Brand]','$_POST[email]','$_POST[login]')";
    $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
    echo "<small class='form-text text-muted'>Покупатель успешно добавлен</small>";
}

$query="SELECT * FROM Buyer";
$result=mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
echo '<table class="table"><caption>Таблица покупателей</caption>
    <tr><th>Имя</th>
        <th>Фамилия</th>
        <th>Телефон</th>
        <th>Отчество</th>
        <th>Бренд</th>
        <th>Почта</th>
        <th>Логин</th></tr>';
while($brandParams=mysqli_fetch_assoc($result))//данные семинара
{
    echo '<tr>';
    echo '<td>';
    echo $brandParams[Name];
    echo '</td><td>';
    echo $brandParams[Surname];
    echo '</td><td>';
    echo $brandParams[PhoneNumber];
    echo '</td><td>';
    echo $brandParams[Patronymic];
    echo '</td><td>';
    $query = 'SELECT Name FROM Brand WHERE ID=' . $brandParams[Brand];
    $result1 = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($link));
    $resultRow = mysqli_fetch_assoc($result1);
    echo $resultRow[Name];
    echo '</td><td>';
    echo $brandParams[email];
    echo '</td><td>';
    echo $brandParams[login];
    echo '</td><td>';
    echo "<a href='http://localhost/kursProject/editBuyer.php?ID=$brandParams[ID]'>Изменить</a></td><td>";
    echo "<a href='http://localhost/kursProject/editBuyers.php?ID=$brandParams[ID]'>Удалить</a></td></tr>";
}
echo "</table><a href='http://localhost/kursProject/editBuyer.php'>Новый покупатель</a>";
?></div></div></body></html>