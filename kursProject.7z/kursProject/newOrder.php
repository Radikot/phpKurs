<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 18.12.2017
 * Time: 23:06
 */
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=1) {
    header("Location: /kursProject/main.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
        th
        {
            text-align: center;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="text-center col-md-10 col-md-offset-1">
        <?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
$query='SELECT * FROM Product';
$productParams=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
?>
            <form action="thanks.php" method="post">
                <div class="text-center">
<table class="table-bordered table"><caption>Товары</caption>
    <tr><th>Артикул</th>
        <th>Наименование</th>
        <th>Стоимость</th>
        <th>Количество</th></tr>
        <?
while($resRow=mysqli_fetch_assoc($productParams))
{
    echo "<tr><td>$resRow[Articul]</td>";
    echo "<td>$resRow[Name]</td>";
    echo "<td>$resRow[Cost]</td>";
    echo "<td><input type='text' name='Number$resRow[ID]' class='form-control'></td></tr>";
}
?>
</table>
                </div>
                <button type="submit" class="btn btn-primary">Заказать</button>
</form>
        </div>
    </div>
</div>
</body>
</html>
