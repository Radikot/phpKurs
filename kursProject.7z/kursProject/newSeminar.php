<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']==1) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 15.12.2017
 * Time: 12:15
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Покупатель</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-4 col-md-offset-4 ">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_POST[Brand])AND isset($_POST[Leader])AND isset($_POST[StartTime])AND isset($_POST[Duration]))
{
    $StartTime=new DateTime($_POST[StartTime]);
    list($h,$m)=explode(":",$_POST[Duration]);
    $DurationInterval=new DateInterval("PT".(int)$h."H".(int)$m."M");
    $FinalTime=date_add($StartTime,$DurationInterval);
    $FinalTimeStr=date_format($FinalTime, 'Y-m-d H:i:s');

    $query="SELECT StartTime, FinalTime FROM seminar";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $f=true;
    while($resRow=mysqli_fetch_assoc($result)AND $f)
    {
        $StartTime1=date_create($resRow[StartTime]);
        $FinalTime1=date_create($resRow[FinalTime]);
        if(!(($StartTime>$FinalTime1 AND $FinalTime>$FinalTime1)OR($StartTime<$StartTime1 AND $FinalTime<$StartTime1)))
            $f=false;
    }
    if ($f) {
        $query = "INSERT INTO seminar (Brand_ID, Topic,Leader_ID,StartTime,Duration,FinalTime)" .
            " VALUES ('$_POST[Brand]','$_POST[Surname]','$_POST[Leader]','$_POST[StartTime]','$_POST[Duration]','$FinalTimeStr')";
        $result = mysqli_query($connection, $query) or die("Ошибка " . mysqli_error($connection));
        echo "<small class='form-text text-muted'>Семинар успешно добавлен</small>";
        } else {
        echo "<small class='form-text text-muted'>В выбранное время нельзя провести семинар</small>";
        }
}
$query='SELECT ID,Name FROM Brand';
$result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
$now=date_create();
$nowStr=$now->format('Y-m-d\TH:i');?>
<form action="newSeminar.php" method="post">
    <div class="form-group">
    <label for="Brand">Бренд семинара</label>
    <select name="Brand" id="Brand" required class="form-control">
    <?
    while ($rowRes=mysqli_fetch_assoc($result))
    {
    echo "<option value='$rowRes[ID]' class='form-control'>$rowRes[Name]</option>";
    }?>
    </select>
    </div>
    <div class="form-group">
    <label for="Topic">Тема семинара</label>
    <input type="text" name="Topic" id="Topic" class="form-control">
    </div>
    <?php
    $query='SELECT ID,Name,Surname FROM Leader';
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($link));
    ?>
    <div class="form-group">
    <label for="Leader">Ведущий семинара</label>
    <select name="Leader" id="Leader" required class="form-control">
        <?
        while ($rowRes=mysqli_fetch_assoc($result))
        {
            echo "<option value='$rowRes[ID]' class='form-control'>$rowRes[Name] $rowRes[Surname]</option>";
        }?>
    </select>
    </div>
    <div class="form-group">
    <label for="StartTime">Начало семинара</label>
    <?php echo "<input type='datetime-local' class='form-control' min=$nowStr id='StartTime' name='StartTime' required>";?>
    </div>
    <div class="form-group">
    <label for="Duration">Продолжительность семинара</label>
    <input type="time" id="Duration" name="Duration" required class="form-control">
    </div>
    <button class="btn btn-primary">Отправить</button>
</form>
</body>
</html>