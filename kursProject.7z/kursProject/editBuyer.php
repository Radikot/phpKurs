<?php
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=3) {
    header("Location: /kursProject/main.php");
    exit;
}
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 10:41
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Бренд</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }

    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling --><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row col-md-4 col-md-offset-4">
<?php
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
if(isset($_GET[ID]))
{
    $query="SELECT * FROM Buyer Where ID='$_GET[ID]'";
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($connection));
    $buyerParams=mysqli_fetch_assoc($result);
    echo "
<form action='editBuyers.php?new=0' method='post'>
<div class='form-group'>
    <label for='Name'>Имя</label>
    <input type='text' id='Name' name='Name' value='$buyerParams[Name]' required class='form-control'>
    </div>
    
    <input type='hidden' name='ID' value='$buyerParams[ID]'>
    <div class='form-group'>
    <label for='Name'>Фамилия</label>
    <input type='text' id='Name' name='Surname' value='$buyerParams[Surname]' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Name'>Телефон</label>
    <input type='text' id='Name' name='PhoneNumber' value='$buyerParams[PhoneNumber]' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Name'>Отчество</label>
    <input type='text' id='Name' name='Patronymic' value='$buyerParams[Patronymic]' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Name'>Бренд</label>
    <select name='Brand' id='Brand' required class='form-control'>";
    $query='SELECT * FROM Brand';
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($link));
    while ($brand=mysqli_fetch_assoc($result))
    {
        if($brand[ID]==$buyerParams[Brand])
            $selected='selected';
        else
            $selected='';
        echo "<option value='$brand[ID]' $selected class='form-control'>$brand[Name]</option>";
    }
    echo "</select>
    </div>";
    echo"
<div class='form-group'>
    <label for='Name'>Почта</label>
    <input type='text' id='Name' name='email' value='$buyerParams[email]' class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Name'>Логин</label>
    <input type='text' id='Name' name='login' value='$buyerParams[login]' required class='form-control'>
    </div>
    <button class='btn btn-primary'>Отправить</button></form> ";
}
else
{echo "
<form action='editBuyers.php?new=1' method='post'>
<div class='form-group'>
    <label for='Name'>Имя</label>
    <input type='text' id='Name' name='Name' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Surname'>Фамилия</label>
    <input type='text' id='Surname' name='Surname' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='PhoneNumber'>Телефон</label>
    <input type='text' id='PhoneNumber' name='PhoneNumber' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Patronymic'>Отчество</label>
    <input type='text' id='Patronymic' name='Patronymic' required class='form-control'>
    </div>
    <div class='form-group'>
    <label for='Brand'>Бренд</label>
    <select name='Brand' id='Brand' required class='form-control'>";
    $query='SELECT * FROM Brand';
    $result=mysqli_query($connection,$query) or die("Ошибка " . mysqli_error($link));
    while ($brand=mysqli_fetch_assoc($result))
    {
        echo "<option value='$brand[ID]' class='form-control'>$brand[Name]</option>";
    }echo "</select></div>"?>
        <div class="form-group">
    <label for='email'>Почта</label>
    <input type='text' id='email' name='email' class='form-control'>
    </div>
        <div class="form-group">
    <label for='login'>Логин</label>
    <input type='text' id='login' name='login' required class='form-control'>
        </div>
        <button class='btn btn-primary'>Отправить</button></form></div></div><?}?>
</body>
</html>