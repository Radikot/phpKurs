<?php
/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 18.12.2017
 * Time: 23:06
 */
session_start();
if (!isset($_SESSION['auth'])OR $_SESSION['level']!=1) {
    header("Location: /kursProject/main.php");
    exit;
}

/**
 * Created by PhpStorm.
 * User: DNS
 * Date: 22.12.2017
 * Time: 1:38
 */
$connection = mysqli_connect('localhost','root','','kursProject') or die('Не удалось соединиться: '.mysqli_error($connection));
$query='SELECT * FROM Product';
$products=mysqli_query($connection,$query) or die("Ошибка 1" . mysqli_error($connection));
$arr=array();
$sum=0;
while($resRow=mysqli_fetch_assoc($products))
{
    if($_POST['Number'.$resRow[ID]]>0)
    {
        $sum+=$resRow[Cost]*(int)($_POST['Number'.$resRow[ID]]);
        $arr[$resRow[ID]]=(int)($_POST['Number'.$resRow[ID]]);
    }
}
$query="Select ID FROM Buyer WHERE login='$_SESSION[ID]'";
$result=mysqli_query($connection,$query) or die("Ошибка 2" . mysqli_error($connection));
$buyerId=mysqli_fetch_assoc($result);
$now=date_create();
$nowStr=date_format($now,'Y-m-d H:i:s');
$sumF=(float)$sum;
$sumFStr=number_format($sumF,2,'.','');

$query="INSERT INTO Order1 (ID_Buyer, Summ, Date) VALUES ('$buyerId[ID]','$sumFStr','$nowStr')";
$result=mysqli_query($connection,$query) or die("Ошибка 3" . mysqli_error($connection));
$query="Select ID FROM Order1 WHERE ID_Buyer='$buyerId[ID]' AND Summ='$sumFStr' AND Date='$nowStr'";
$result=mysqli_query($connection,$query) or die("Ошибка 4" . mysqli_error($connection));
$orderId=mysqli_fetch_assoc($result);
$query='SELECT * FROM Product';
$products=mysqli_query($connection,$query) or die("Ошибка 4" . mysqli_error($connection));
while($resRow=mysqli_fetch_assoc($products))
{
    if($_POST['Number'.$resRow[ID]]>0)
    {

        $productNum=$_POST['Number'.$resRow[ID]];
        $query="INSERT INTO Order_Product (Order_ID,Product_ID,Number) VALUES ($orderId[ID],$resRow[ID],$productNum)";
        $result=mysqli_query($connection,$query) or die("Ошибка 5" . mysqli_error($connection));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="refresh" content="2; URL='/kursProject/Buyer.php'" />
<head>
    <meta charset="UTF-8">
    <title>Завершение заказа</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>-->
    <style type="text/css">
        body
        {
            padding-top: 90px;
        }
        .navbar-brand
        {
            height: 70px;
            padding:0px 10px;
        }
    </style>
    <script src="jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="/kursProject/main.php"><img src="img/logo.png"></a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
    <div class="row">
        <div class="text-center" >
            <h4>Спасибо за покупку!</h4>
        </div>
    </div>
</div>
</body></html>
